import '../handlers/handlers.dart';
import '../../infrastructure/models/models.dart';

abstract class CatalogRepository {
  Future<ApiResult<UnitsPaginateResponse>> getUnits();

  Future<ApiResult<void>> createCategory({required String title});

  Future<ApiResult<CategoriesPaginateResponse>> getCategories({
    int? page,
    String? query,
  });
}
