class OrdinalSales {
  final String day;
  final int sales;

  OrdinalSales({required this.day, required this.sales});
}