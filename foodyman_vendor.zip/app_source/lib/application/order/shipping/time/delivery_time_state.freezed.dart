// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'delivery_time_state.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$DeliveryTimeState {
  String get deliveryDate => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $DeliveryTimeStateCopyWith<DeliveryTimeState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DeliveryTimeStateCopyWith<$Res> {
  factory $DeliveryTimeStateCopyWith(
          DeliveryTimeState value, $Res Function(DeliveryTimeState) then) =
      _$DeliveryTimeStateCopyWithImpl<$Res, DeliveryTimeState>;
  @useResult
  $Res call({String deliveryDate});
}

/// @nodoc
class _$DeliveryTimeStateCopyWithImpl<$Res, $Val extends DeliveryTimeState>
    implements $DeliveryTimeStateCopyWith<$Res> {
  _$DeliveryTimeStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? deliveryDate = null,
  }) {
    return _then(_value.copyWith(
      deliveryDate: null == deliveryDate
          ? _value.deliveryDate
          : deliveryDate // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_DeliveryTimeStateCopyWith<$Res>
    implements $DeliveryTimeStateCopyWith<$Res> {
  factory _$$_DeliveryTimeStateCopyWith(_$_DeliveryTimeState value,
          $Res Function(_$_DeliveryTimeState) then) =
      __$$_DeliveryTimeStateCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({String deliveryDate});
}

/// @nodoc
class __$$_DeliveryTimeStateCopyWithImpl<$Res>
    extends _$DeliveryTimeStateCopyWithImpl<$Res, _$_DeliveryTimeState>
    implements _$$_DeliveryTimeStateCopyWith<$Res> {
  __$$_DeliveryTimeStateCopyWithImpl(
      _$_DeliveryTimeState _value, $Res Function(_$_DeliveryTimeState) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? deliveryDate = null,
  }) {
    return _then(_$_DeliveryTimeState(
      deliveryDate: null == deliveryDate
          ? _value.deliveryDate
          : deliveryDate // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$_DeliveryTimeState extends _DeliveryTimeState {
  const _$_DeliveryTimeState({this.deliveryDate = ''}) : super._();

  @override
  @JsonKey()
  final String deliveryDate;

  @override
  String toString() {
    return 'DeliveryTimeState(deliveryDate: $deliveryDate)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_DeliveryTimeState &&
            (identical(other.deliveryDate, deliveryDate) ||
                other.deliveryDate == deliveryDate));
  }

  @override
  int get hashCode => Object.hash(runtimeType, deliveryDate);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_DeliveryTimeStateCopyWith<_$_DeliveryTimeState> get copyWith =>
      __$$_DeliveryTimeStateCopyWithImpl<_$_DeliveryTimeState>(
          this, _$identity);
}

abstract class _DeliveryTimeState extends DeliveryTimeState {
  const factory _DeliveryTimeState({final String deliveryDate}) =
      _$_DeliveryTimeState;
  const _DeliveryTimeState._() : super._();

  @override
  String get deliveryDate;
  @override
  @JsonKey(ignore: true)
  _$$_DeliveryTimeStateCopyWith<_$_DeliveryTimeState> get copyWith =>
      throw _privateConstructorUsedError;
}
