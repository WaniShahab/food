// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'delete_extras_item_state.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$DeleteExtrasItemState {
  bool get isLoading => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $DeleteExtrasItemStateCopyWith<DeleteExtrasItemState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DeleteExtrasItemStateCopyWith<$Res> {
  factory $DeleteExtrasItemStateCopyWith(DeleteExtrasItemState value,
          $Res Function(DeleteExtrasItemState) then) =
      _$DeleteExtrasItemStateCopyWithImpl<$Res, DeleteExtrasItemState>;
  @useResult
  $Res call({bool isLoading});
}

/// @nodoc
class _$DeleteExtrasItemStateCopyWithImpl<$Res,
        $Val extends DeleteExtrasItemState>
    implements $DeleteExtrasItemStateCopyWith<$Res> {
  _$DeleteExtrasItemStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isLoading = null,
  }) {
    return _then(_value.copyWith(
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_DeleteExtrasItemStateCopyWith<$Res>
    implements $DeleteExtrasItemStateCopyWith<$Res> {
  factory _$$_DeleteExtrasItemStateCopyWith(_$_DeleteExtrasItemState value,
          $Res Function(_$_DeleteExtrasItemState) then) =
      __$$_DeleteExtrasItemStateCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({bool isLoading});
}

/// @nodoc
class __$$_DeleteExtrasItemStateCopyWithImpl<$Res>
    extends _$DeleteExtrasItemStateCopyWithImpl<$Res, _$_DeleteExtrasItemState>
    implements _$$_DeleteExtrasItemStateCopyWith<$Res> {
  __$$_DeleteExtrasItemStateCopyWithImpl(_$_DeleteExtrasItemState _value,
      $Res Function(_$_DeleteExtrasItemState) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isLoading = null,
  }) {
    return _then(_$_DeleteExtrasItemState(
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$_DeleteExtrasItemState extends _DeleteExtrasItemState {
  const _$_DeleteExtrasItemState({this.isLoading = false}) : super._();

  @override
  @JsonKey()
  final bool isLoading;

  @override
  String toString() {
    return 'DeleteExtrasItemState(isLoading: $isLoading)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_DeleteExtrasItemState &&
            (identical(other.isLoading, isLoading) ||
                other.isLoading == isLoading));
  }

  @override
  int get hashCode => Object.hash(runtimeType, isLoading);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_DeleteExtrasItemStateCopyWith<_$_DeleteExtrasItemState> get copyWith =>
      __$$_DeleteExtrasItemStateCopyWithImpl<_$_DeleteExtrasItemState>(
          this, _$identity);
}

abstract class _DeleteExtrasItemState extends DeleteExtrasItemState {
  const factory _DeleteExtrasItemState({final bool isLoading}) =
      _$_DeleteExtrasItemState;
  const _DeleteExtrasItemState._() : super._();

  @override
  bool get isLoading;
  @override
  @JsonKey(ignore: true)
  _$$_DeleteExtrasItemStateCopyWith<_$_DeleteExtrasItemState> get copyWith =>
      throw _privateConstructorUsedError;
}
