// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'create_new_group_item_state.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$CreateNewGroupItemState {
  bool get isLoading => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $CreateNewGroupItemStateCopyWith<CreateNewGroupItemState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CreateNewGroupItemStateCopyWith<$Res> {
  factory $CreateNewGroupItemStateCopyWith(CreateNewGroupItemState value,
          $Res Function(CreateNewGroupItemState) then) =
      _$CreateNewGroupItemStateCopyWithImpl<$Res, CreateNewGroupItemState>;
  @useResult
  $Res call({bool isLoading});
}

/// @nodoc
class _$CreateNewGroupItemStateCopyWithImpl<$Res,
        $Val extends CreateNewGroupItemState>
    implements $CreateNewGroupItemStateCopyWith<$Res> {
  _$CreateNewGroupItemStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isLoading = null,
  }) {
    return _then(_value.copyWith(
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_CreateNewGroupItemStateCopyWith<$Res>
    implements $CreateNewGroupItemStateCopyWith<$Res> {
  factory _$$_CreateNewGroupItemStateCopyWith(_$_CreateNewGroupItemState value,
          $Res Function(_$_CreateNewGroupItemState) then) =
      __$$_CreateNewGroupItemStateCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({bool isLoading});
}

/// @nodoc
class __$$_CreateNewGroupItemStateCopyWithImpl<$Res>
    extends _$CreateNewGroupItemStateCopyWithImpl<$Res,
        _$_CreateNewGroupItemState>
    implements _$$_CreateNewGroupItemStateCopyWith<$Res> {
  __$$_CreateNewGroupItemStateCopyWithImpl(_$_CreateNewGroupItemState _value,
      $Res Function(_$_CreateNewGroupItemState) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isLoading = null,
  }) {
    return _then(_$_CreateNewGroupItemState(
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$_CreateNewGroupItemState extends _CreateNewGroupItemState {
  const _$_CreateNewGroupItemState({this.isLoading = false}) : super._();

  @override
  @JsonKey()
  final bool isLoading;

  @override
  String toString() {
    return 'CreateNewGroupItemState(isLoading: $isLoading)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_CreateNewGroupItemState &&
            (identical(other.isLoading, isLoading) ||
                other.isLoading == isLoading));
  }

  @override
  int get hashCode => Object.hash(runtimeType, isLoading);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_CreateNewGroupItemStateCopyWith<_$_CreateNewGroupItemState>
      get copyWith =>
          __$$_CreateNewGroupItemStateCopyWithImpl<_$_CreateNewGroupItemState>(
              this, _$identity);
}

abstract class _CreateNewGroupItemState extends CreateNewGroupItemState {
  const factory _CreateNewGroupItemState({final bool isLoading}) =
      _$_CreateNewGroupItemState;
  const _CreateNewGroupItemState._() : super._();

  @override
  bool get isLoading;
  @override
  @JsonKey(ignore: true)
  _$$_CreateNewGroupItemStateCopyWith<_$_CreateNewGroupItemState>
      get copyWith => throw _privateConstructorUsedError;
}
