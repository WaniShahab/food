// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'create_addon_state.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$CreateAddonState {
  bool get isLoading => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $CreateAddonStateCopyWith<CreateAddonState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CreateAddonStateCopyWith<$Res> {
  factory $CreateAddonStateCopyWith(
          CreateAddonState value, $Res Function(CreateAddonState) then) =
      _$CreateAddonStateCopyWithImpl<$Res, CreateAddonState>;
  @useResult
  $Res call({bool isLoading});
}

/// @nodoc
class _$CreateAddonStateCopyWithImpl<$Res, $Val extends CreateAddonState>
    implements $CreateAddonStateCopyWith<$Res> {
  _$CreateAddonStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isLoading = null,
  }) {
    return _then(_value.copyWith(
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_CreateAddonStateCopyWith<$Res>
    implements $CreateAddonStateCopyWith<$Res> {
  factory _$$_CreateAddonStateCopyWith(
          _$_CreateAddonState value, $Res Function(_$_CreateAddonState) then) =
      __$$_CreateAddonStateCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({bool isLoading});
}

/// @nodoc
class __$$_CreateAddonStateCopyWithImpl<$Res>
    extends _$CreateAddonStateCopyWithImpl<$Res, _$_CreateAddonState>
    implements _$$_CreateAddonStateCopyWith<$Res> {
  __$$_CreateAddonStateCopyWithImpl(
      _$_CreateAddonState _value, $Res Function(_$_CreateAddonState) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isLoading = null,
  }) {
    return _then(_$_CreateAddonState(
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$_CreateAddonState extends _CreateAddonState {
  const _$_CreateAddonState({this.isLoading = false}) : super._();

  @override
  @JsonKey()
  final bool isLoading;

  @override
  String toString() {
    return 'CreateAddonState(isLoading: $isLoading)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_CreateAddonState &&
            (identical(other.isLoading, isLoading) ||
                other.isLoading == isLoading));
  }

  @override
  int get hashCode => Object.hash(runtimeType, isLoading);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_CreateAddonStateCopyWith<_$_CreateAddonState> get copyWith =>
      __$$_CreateAddonStateCopyWithImpl<_$_CreateAddonState>(this, _$identity);
}

abstract class _CreateAddonState extends CreateAddonState {
  const factory _CreateAddonState({final bool isLoading}) = _$_CreateAddonState;
  const _CreateAddonState._() : super._();

  @override
  bool get isLoading;
  @override
  @JsonKey(ignore: true)
  _$$_CreateAddonStateCopyWith<_$_CreateAddonState> get copyWith =>
      throw _privateConstructorUsedError;
}
