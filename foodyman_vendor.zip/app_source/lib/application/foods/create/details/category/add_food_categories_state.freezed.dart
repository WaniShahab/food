// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'add_food_categories_state.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$AddFoodCategoriesState {
  List<CategoryData> get categories => throw _privateConstructorUsedError;
  int get activeIndex => throw _privateConstructorUsedError;
  TextEditingController? get categoryController =>
      throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $AddFoodCategoriesStateCopyWith<AddFoodCategoriesState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $AddFoodCategoriesStateCopyWith<$Res> {
  factory $AddFoodCategoriesStateCopyWith(AddFoodCategoriesState value,
          $Res Function(AddFoodCategoriesState) then) =
      _$AddFoodCategoriesStateCopyWithImpl<$Res, AddFoodCategoriesState>;
  @useResult
  $Res call(
      {List<CategoryData> categories,
      int activeIndex,
      TextEditingController? categoryController});
}

/// @nodoc
class _$AddFoodCategoriesStateCopyWithImpl<$Res,
        $Val extends AddFoodCategoriesState>
    implements $AddFoodCategoriesStateCopyWith<$Res> {
  _$AddFoodCategoriesStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? categories = null,
    Object? activeIndex = null,
    Object? categoryController = freezed,
  }) {
    return _then(_value.copyWith(
      categories: null == categories
          ? _value.categories
          : categories // ignore: cast_nullable_to_non_nullable
              as List<CategoryData>,
      activeIndex: null == activeIndex
          ? _value.activeIndex
          : activeIndex // ignore: cast_nullable_to_non_nullable
              as int,
      categoryController: freezed == categoryController
          ? _value.categoryController
          : categoryController // ignore: cast_nullable_to_non_nullable
              as TextEditingController?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_AddFoodCategoriesStateCopyWith<$Res>
    implements $AddFoodCategoriesStateCopyWith<$Res> {
  factory _$$_AddFoodCategoriesStateCopyWith(_$_AddFoodCategoriesState value,
          $Res Function(_$_AddFoodCategoriesState) then) =
      __$$_AddFoodCategoriesStateCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {List<CategoryData> categories,
      int activeIndex,
      TextEditingController? categoryController});
}

/// @nodoc
class __$$_AddFoodCategoriesStateCopyWithImpl<$Res>
    extends _$AddFoodCategoriesStateCopyWithImpl<$Res,
        _$_AddFoodCategoriesState>
    implements _$$_AddFoodCategoriesStateCopyWith<$Res> {
  __$$_AddFoodCategoriesStateCopyWithImpl(_$_AddFoodCategoriesState _value,
      $Res Function(_$_AddFoodCategoriesState) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? categories = null,
    Object? activeIndex = null,
    Object? categoryController = freezed,
  }) {
    return _then(_$_AddFoodCategoriesState(
      categories: null == categories
          ? _value._categories
          : categories // ignore: cast_nullable_to_non_nullable
              as List<CategoryData>,
      activeIndex: null == activeIndex
          ? _value.activeIndex
          : activeIndex // ignore: cast_nullable_to_non_nullable
              as int,
      categoryController: freezed == categoryController
          ? _value.categoryController
          : categoryController // ignore: cast_nullable_to_non_nullable
              as TextEditingController?,
    ));
  }
}

/// @nodoc

class _$_AddFoodCategoriesState extends _AddFoodCategoriesState {
  const _$_AddFoodCategoriesState(
      {final List<CategoryData> categories = const [],
      this.activeIndex = 1,
      this.categoryController})
      : _categories = categories,
        super._();

  final List<CategoryData> _categories;
  @override
  @JsonKey()
  List<CategoryData> get categories {
    if (_categories is EqualUnmodifiableListView) return _categories;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_categories);
  }

  @override
  @JsonKey()
  final int activeIndex;
  @override
  final TextEditingController? categoryController;

  @override
  String toString() {
    return 'AddFoodCategoriesState(categories: $categories, activeIndex: $activeIndex, categoryController: $categoryController)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_AddFoodCategoriesState &&
            const DeepCollectionEquality()
                .equals(other._categories, _categories) &&
            (identical(other.activeIndex, activeIndex) ||
                other.activeIndex == activeIndex) &&
            (identical(other.categoryController, categoryController) ||
                other.categoryController == categoryController));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(_categories),
      activeIndex,
      categoryController);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_AddFoodCategoriesStateCopyWith<_$_AddFoodCategoriesState> get copyWith =>
      __$$_AddFoodCategoriesStateCopyWithImpl<_$_AddFoodCategoriesState>(
          this, _$identity);
}

abstract class _AddFoodCategoriesState extends AddFoodCategoriesState {
  const factory _AddFoodCategoriesState(
          {final List<CategoryData> categories,
          final int activeIndex,
          final TextEditingController? categoryController}) =
      _$_AddFoodCategoriesState;
  const _AddFoodCategoriesState._() : super._();

  @override
  List<CategoryData> get categories;
  @override
  int get activeIndex;
  @override
  TextEditingController? get categoryController;
  @override
  @JsonKey(ignore: true)
  _$$_AddFoodCategoriesStateCopyWith<_$_AddFoodCategoriesState> get copyWith =>
      throw _privateConstructorUsedError;
}
