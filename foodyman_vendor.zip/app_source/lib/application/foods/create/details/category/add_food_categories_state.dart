import 'package:flutter/material.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import '../../../../../infrastructure/models/models.dart';

part 'add_food_categories_state.freezed.dart';

@freezed
class AddFoodCategoriesState with _$AddFoodCategoriesState {
  const factory AddFoodCategoriesState({
    @Default([]) List<CategoryData> categories,
    @Default(1) int activeIndex,
    TextEditingController? categoryController,
  }) = _AddFoodCategoriesState;

  const AddFoodCategoriesState._();
}
