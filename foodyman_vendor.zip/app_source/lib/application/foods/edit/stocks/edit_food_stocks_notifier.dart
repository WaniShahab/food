import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../infrastructure/services/services.dart';
import 'edit_food_stocks_state.dart';
import '../../../../domain/interface/interfaces.dart';
import '../../../../infrastructure/models/models.dart';

class EditFoodStocksNotifier extends StateNotifier<EditFoodStocksState> {
  final ProductsRepository _productsRepository;
  List<Stock> _localStocks = [];

  EditFoodStocksNotifier(this._productsRepository)
      : super(const EditFoodStocksState());

  void setStockAddons(List<ProductData> addons, int stockIndex) {
    List<AddonData> checkedAddons = [];
    for (final addon in addons) {
      if (addon.isSelectedAddon ?? false) {
        checkedAddons.add(AddonData(addonId: addon.id, product: addon));
      }
    }
    _localStocks[stockIndex] =
        _localStocks[stockIndex].copyWith(localAddons: checkedAddons);
    state = state.copyWith(stocks: _localStocks);
    debugPrint('===> set selected addon ${_localStocks[stockIndex].localAddons?.length}');
  }

  List<Group> _getCheckedGroups(List<Group> groups, List<Stock> stocks) {
    List<Group> activeGroups = [];
    for (final group in groups) {
      if (group.isChecked ?? false) {
        activeGroups.add(group);
      }
    }
    if (stocks.isNotEmpty) {
      List<Extras> extras = stocks.first.extras ?? [];
      List<int> ids = extras.map((e) => e.extraGroupId ?? 0).toList();
      List<Group> sortedGroups = [];
      for (final id in ids) {
        for (final group in activeGroups) {
          if (group.id == id) {
            sortedGroups.add(group);
          }
        }
      }
      return sortedGroups;
    }
    return activeGroups;
  }

  void toggleCheckedGroup(int groupIndex) {
    List<Group> groups = List.from(state.groups);
    final currentGroup = groups[groupIndex]
        .copyWith(isChecked: !(groups[groupIndex].isChecked ?? false));
    groups[groupIndex] = currentGroup;
    List<Stock> stocks = List.from(state.stocks);
    for (int i = 0; i < stocks.length; i++) {
      List<Extras> extras = stocks[i].extras ?? [];
      if (currentGroup.isChecked ?? false) {
        extras.add(
          Extras(extraGroupId: currentGroup.id, group: currentGroup),
        );
      } else {
        int? index;
        for (int j = 0; j < extras.length; j++) {
          if (extras[j].extraGroupId == currentGroup.id) {
            index = j;
          }
        }
        if (index != null) {
          extras.removeAt(index);
        }
      }
      stocks[i] = stocks[i].copyWith(extras: extras);
    }
    final List<Group> checkedGroups = _getCheckedGroups(groups, stocks);
    _localStocks = checkedGroups.isEmpty ? stocks.sublist(0, 1) : stocks;
    state = state.copyWith(
      groups: groups,
      stocks: _localStocks,
      activeGroups: checkedGroups,
    );
  }

  List<Group> _checkGroupsChecked(List<Group> groups, ProductData product) {
    for (int i = 0; i < groups.length; i++) {
      groups[i] = groups[i].copyWith(isChecked: false);
    }
    final List<Stock> stocks = product.stocks ?? [];
    if (stocks.isNotEmpty) {
      final List<Extras> stockExtras = stocks.first.extras ?? [];
      for (int i = 0; i < groups.length; i++) {
        for (final extras in stockExtras) {
          if (extras.extraGroupId == groups[i].id) {
            groups[i] = groups[i].copyWith(isChecked: true);
          }
        }
      }
    }
    return groups;
  }

  Future<void> fetchGroups({required ProductData product}) async {
    if (state.groups.isNotEmpty) {
      List<Group> groups = List.from(state.groups);
      groups = _checkGroupsChecked(groups, product);
      state = state.copyWith(
        groups: groups,
        activeGroups: _getCheckedGroups(groups, state.stocks),
      );
      return;
    }
    state = state.copyWith(isFetchingGroups: true);
    final response = await _productsRepository.getExtrasGroups();
    response.when(
      success: (data) {
        List<Group> groups = data.data ?? [];
        state = state.copyWith(
          groups: _checkGroupsChecked(groups, product),
          activeGroups: _getCheckedGroups(groups, state.stocks),
          isFetchingGroups: false,
        );
      },
      failure: (fail,status) {
        state = state.copyWith(isFetchingGroups: false);
      },
    );
  }

  void setActiveExtrasIndex({
    required int itemIndex,
    required int groupIndex,
    required int stockIndex,
  }) {
    final List<Extras> currentFetchedExtras =
        state.activeGroups[groupIndex].fetchedExtras ?? [];
    List<Extras>? currentStockExtras = _localStocks[stockIndex].extras;
    int? stockExtrasIndex;
    if (currentStockExtras != null && currentStockExtras.isNotEmpty) {
      for (int i = 0; i < currentFetchedExtras.length; i++) {
        for (int j = 0; j < currentStockExtras.length; j++) {
          if (currentFetchedExtras[i].extraGroupId ==
                  currentStockExtras[j].extraGroupId &&
              currentStockExtras[j].id == currentFetchedExtras[i].id) {
            stockExtrasIndex = j;
          }
        }
      }
      if (stockExtrasIndex != null) {
        currentStockExtras[stockExtrasIndex] = currentFetchedExtras[itemIndex];
        _localStocks[stockIndex] =
            _localStocks[stockIndex].copyWith(extras: currentStockExtras);
      }
    }
    state = state.copyWith(
      isLoading: false,
      activeGroupExtras: currentFetchedExtras,
      stocks: _localStocks,
      activeExtrasIndex: itemIndex,
    );
  }

  Future<void> fetchGroupExtras({
    required int groupIndex,
    required int stockIndex,
  }) async {
    if (state.activeGroups[groupIndex].fetchedExtras?.isNotEmpty ?? false) {
      final List<Extras> currentFetchedExtras =
          state.activeGroups[groupIndex].fetchedExtras ?? [];
      List<Extras>? currentStockExtras = _localStocks[stockIndex].extras;
      int? stockExtrasIndex;
      int? selectedGroupIndex;
      if (currentStockExtras != null && currentStockExtras.isNotEmpty) {
        for (int i = 0; i < currentFetchedExtras.length; i++) {
          for (int j = 0; j < currentStockExtras.length; j++) {
            if (currentFetchedExtras[i].extraGroupId ==
                currentStockExtras[j].extraGroupId) {
              stockExtrasIndex = j;
              if (currentStockExtras[j].id == currentFetchedExtras[i].id) {
                selectedGroupIndex = i;
              }
            }
          }
        }
        if (stockExtrasIndex != null) {
          currentStockExtras[stockExtrasIndex] =
              currentFetchedExtras[selectedGroupIndex ?? 0];
          _localStocks[stockIndex] =
              _localStocks[stockIndex].copyWith(extras: currentStockExtras);
        }
      }
      state = state.copyWith(
        activeGroupExtras: currentFetchedExtras,
        stocks: _localStocks,
        activeExtrasIndex: selectedGroupIndex ?? 0,
      );
      return;
    }
    state = state.copyWith(isLoading: true);
    final response = await _productsRepository.getExtras(
      groupId: state.activeGroups[groupIndex].id,
    );
    response.when(
      success: (data) {
        final List<Extras> fetchedExtras = data.data?.extraValues ?? <Extras>[];
        List<Group> activeGroups = List.from(state.activeGroups);
        activeGroups[groupIndex] =
            activeGroups[groupIndex].copyWith(fetchedExtras: fetchedExtras);
        List<Extras>? currentStockExtras = _localStocks[stockIndex].extras;
        int? stockExtrasIndex;
        int? selectedGroupIndex;
        if (currentStockExtras != null && currentStockExtras.isNotEmpty) {
          for (int i = 0; i < fetchedExtras.length; i++) {
            for (int j = 0; j < currentStockExtras.length; j++) {
              if (fetchedExtras[i].extraGroupId ==
                  currentStockExtras[j].extraGroupId) {
                stockExtrasIndex = j;
                if (currentStockExtras[j].id == fetchedExtras[i].id) {
                  selectedGroupIndex = i;
                }
              }
            }
          }
          if (stockExtrasIndex != null) {
            currentStockExtras[stockExtrasIndex] =
                fetchedExtras[selectedGroupIndex ?? 0];
            _localStocks[stockIndex] =
                _localStocks[stockIndex].copyWith(extras: currentStockExtras);
          }
        } else {
          if (fetchedExtras.isNotEmpty) {
            currentStockExtras = [fetchedExtras.first];
          } else {
            currentStockExtras = [
              Extras(
                extraGroupId: activeGroups[groupIndex].id,
                group: activeGroups[groupIndex],
              ),
            ];
          }
          _localStocks[stockIndex] =
              _localStocks[stockIndex].copyWith(extras: currentStockExtras);
        }

        /// save fetched extras to groups
        List<Group> groups = List.from(state.groups);
        int mainGroupIndex = 0;
        for (int i = 0; i < groups.length; i++) {
          if (groups[i].id == activeGroups[groupIndex].id) {
            mainGroupIndex = i;
          }
        }
        groups[mainGroupIndex] =
            groups[mainGroupIndex].copyWith(fetchedExtras: fetchedExtras);
        state = state.copyWith(
          isLoading: false,
          activeGroupExtras: fetchedExtras,
          activeGroups: activeGroups,
          groups: groups,
          stocks: _localStocks,
          activeExtrasIndex: selectedGroupIndex ?? 0,
        );
      },
      failure: (fail,status) {
        state = state.copyWith(isLoading: false);
        debugPrint('===> group extras fetching failed $fail');
      },
    );
  }

  void deleteStock(int index) {
    _localStocks.removeAt(index);
    state = state.copyWith(stocks: _localStocks);
  }

  void setQuantity({required String value, required int index}) {
    _localStocks[index] =
        _localStocks[index].copyWith(quantity: int.tryParse(value.trim()));
  }

  void setPrice({required String value, required int index}) {
    _localStocks[index] =
        _localStocks[index].copyWith(price: num.tryParse(value.trim()));
  }

  Future<void> updateStocks(BuildContext context,{
    String? uuid,
    VoidCallback? updated,
    VoidCallback? failed,
  }) async {
    state = state.copyWith(isSaving: true);
    for(final item in _localStocks) {
      debugPrint('===> update stocks ${item.localAddons?.length}');
    }
    final response = await _productsRepository.updateStocks(
      stocks: _localStocks,
      uuid: uuid,
    );
    response.when(
      success: (data) {
        state = state.copyWith(isSaving: false);
        updated?.call();
      },
      failure: (fail,status) {
        state = state.copyWith(isSaving: false);
        AppHelpers.showCheckTopSnackBar(
            context,
            text: AppHelpers.trans(
              status.toString(),
            ),
            type: SnackBarType.error
        );
        failed?.call();
      },
    );
  }

  void addEmptyStock() {
    List<Extras>? extras = _localStocks.last.extras;
    extras = extras?.map((e) => e.copyWith(value: '')).toList();
    _localStocks
        .add(_localStocks.last.copyWith(isInitial: true, extras: extras));
    state = state.copyWith(stocks: _localStocks);
  }

  void setInitialStocks(ProductData product) {
    final List<Stock> stocks = product.stocks ?? [];
    if (stocks.isEmpty) {
      stocks.add(Stock());
    }
    state = state.copyWith(stocks: stocks);
    _localStocks = stocks;
    fetchGroups(product: product);
  }
}
