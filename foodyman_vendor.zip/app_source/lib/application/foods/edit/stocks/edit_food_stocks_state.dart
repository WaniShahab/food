import 'package:freezed_annotation/freezed_annotation.dart';

import '../../../../infrastructure/models/models.dart';

part 'edit_food_stocks_state.freezed.dart';

@freezed
class EditFoodStocksState with _$EditFoodStocksState {
  const factory EditFoodStocksState({
    @Default(false) bool isLoading,
    @Default(false) bool isSaving,
    @Default(false) bool isFetchingGroups,
    @Default([]) List<Group> groups,
    @Default([]) List<Group> activeGroups,
    @Default([]) List<Stock> stocks,
    @Default([]) List<Extras> activeGroupExtras,
    @Default(0) int activeExtrasIndex,
  }) = _EditFoodStocksState;

  const EditFoodStocksState._();
}
