// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'edit_food_stocks_state.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$EditFoodStocksState {
  bool get isLoading => throw _privateConstructorUsedError;
  bool get isSaving => throw _privateConstructorUsedError;
  bool get isFetchingGroups => throw _privateConstructorUsedError;
  List<Group> get groups => throw _privateConstructorUsedError;
  List<Group> get activeGroups => throw _privateConstructorUsedError;
  List<Stock> get stocks => throw _privateConstructorUsedError;
  List<Extras> get activeGroupExtras => throw _privateConstructorUsedError;
  int get activeExtrasIndex => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $EditFoodStocksStateCopyWith<EditFoodStocksState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $EditFoodStocksStateCopyWith<$Res> {
  factory $EditFoodStocksStateCopyWith(
          EditFoodStocksState value, $Res Function(EditFoodStocksState) then) =
      _$EditFoodStocksStateCopyWithImpl<$Res, EditFoodStocksState>;
  @useResult
  $Res call(
      {bool isLoading,
      bool isSaving,
      bool isFetchingGroups,
      List<Group> groups,
      List<Group> activeGroups,
      List<Stock> stocks,
      List<Extras> activeGroupExtras,
      int activeExtrasIndex});
}

/// @nodoc
class _$EditFoodStocksStateCopyWithImpl<$Res, $Val extends EditFoodStocksState>
    implements $EditFoodStocksStateCopyWith<$Res> {
  _$EditFoodStocksStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isLoading = null,
    Object? isSaving = null,
    Object? isFetchingGroups = null,
    Object? groups = null,
    Object? activeGroups = null,
    Object? stocks = null,
    Object? activeGroupExtras = null,
    Object? activeExtrasIndex = null,
  }) {
    return _then(_value.copyWith(
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      isSaving: null == isSaving
          ? _value.isSaving
          : isSaving // ignore: cast_nullable_to_non_nullable
              as bool,
      isFetchingGroups: null == isFetchingGroups
          ? _value.isFetchingGroups
          : isFetchingGroups // ignore: cast_nullable_to_non_nullable
              as bool,
      groups: null == groups
          ? _value.groups
          : groups // ignore: cast_nullable_to_non_nullable
              as List<Group>,
      activeGroups: null == activeGroups
          ? _value.activeGroups
          : activeGroups // ignore: cast_nullable_to_non_nullable
              as List<Group>,
      stocks: null == stocks
          ? _value.stocks
          : stocks // ignore: cast_nullable_to_non_nullable
              as List<Stock>,
      activeGroupExtras: null == activeGroupExtras
          ? _value.activeGroupExtras
          : activeGroupExtras // ignore: cast_nullable_to_non_nullable
              as List<Extras>,
      activeExtrasIndex: null == activeExtrasIndex
          ? _value.activeExtrasIndex
          : activeExtrasIndex // ignore: cast_nullable_to_non_nullable
              as int,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_EditFoodStocksStateCopyWith<$Res>
    implements $EditFoodStocksStateCopyWith<$Res> {
  factory _$$_EditFoodStocksStateCopyWith(_$_EditFoodStocksState value,
          $Res Function(_$_EditFoodStocksState) then) =
      __$$_EditFoodStocksStateCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {bool isLoading,
      bool isSaving,
      bool isFetchingGroups,
      List<Group> groups,
      List<Group> activeGroups,
      List<Stock> stocks,
      List<Extras> activeGroupExtras,
      int activeExtrasIndex});
}

/// @nodoc
class __$$_EditFoodStocksStateCopyWithImpl<$Res>
    extends _$EditFoodStocksStateCopyWithImpl<$Res, _$_EditFoodStocksState>
    implements _$$_EditFoodStocksStateCopyWith<$Res> {
  __$$_EditFoodStocksStateCopyWithImpl(_$_EditFoodStocksState _value,
      $Res Function(_$_EditFoodStocksState) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isLoading = null,
    Object? isSaving = null,
    Object? isFetchingGroups = null,
    Object? groups = null,
    Object? activeGroups = null,
    Object? stocks = null,
    Object? activeGroupExtras = null,
    Object? activeExtrasIndex = null,
  }) {
    return _then(_$_EditFoodStocksState(
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      isSaving: null == isSaving
          ? _value.isSaving
          : isSaving // ignore: cast_nullable_to_non_nullable
              as bool,
      isFetchingGroups: null == isFetchingGroups
          ? _value.isFetchingGroups
          : isFetchingGroups // ignore: cast_nullable_to_non_nullable
              as bool,
      groups: null == groups
          ? _value._groups
          : groups // ignore: cast_nullable_to_non_nullable
              as List<Group>,
      activeGroups: null == activeGroups
          ? _value._activeGroups
          : activeGroups // ignore: cast_nullable_to_non_nullable
              as List<Group>,
      stocks: null == stocks
          ? _value._stocks
          : stocks // ignore: cast_nullable_to_non_nullable
              as List<Stock>,
      activeGroupExtras: null == activeGroupExtras
          ? _value._activeGroupExtras
          : activeGroupExtras // ignore: cast_nullable_to_non_nullable
              as List<Extras>,
      activeExtrasIndex: null == activeExtrasIndex
          ? _value.activeExtrasIndex
          : activeExtrasIndex // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$_EditFoodStocksState extends _EditFoodStocksState {
  const _$_EditFoodStocksState(
      {this.isLoading = false,
      this.isSaving = false,
      this.isFetchingGroups = false,
      final List<Group> groups = const [],
      final List<Group> activeGroups = const [],
      final List<Stock> stocks = const [],
      final List<Extras> activeGroupExtras = const [],
      this.activeExtrasIndex = 0})
      : _groups = groups,
        _activeGroups = activeGroups,
        _stocks = stocks,
        _activeGroupExtras = activeGroupExtras,
        super._();

  @override
  @JsonKey()
  final bool isLoading;
  @override
  @JsonKey()
  final bool isSaving;
  @override
  @JsonKey()
  final bool isFetchingGroups;
  final List<Group> _groups;
  @override
  @JsonKey()
  List<Group> get groups {
    if (_groups is EqualUnmodifiableListView) return _groups;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_groups);
  }

  final List<Group> _activeGroups;
  @override
  @JsonKey()
  List<Group> get activeGroups {
    if (_activeGroups is EqualUnmodifiableListView) return _activeGroups;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_activeGroups);
  }

  final List<Stock> _stocks;
  @override
  @JsonKey()
  List<Stock> get stocks {
    if (_stocks is EqualUnmodifiableListView) return _stocks;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_stocks);
  }

  final List<Extras> _activeGroupExtras;
  @override
  @JsonKey()
  List<Extras> get activeGroupExtras {
    if (_activeGroupExtras is EqualUnmodifiableListView)
      return _activeGroupExtras;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_activeGroupExtras);
  }

  @override
  @JsonKey()
  final int activeExtrasIndex;

  @override
  String toString() {
    return 'EditFoodStocksState(isLoading: $isLoading, isSaving: $isSaving, isFetchingGroups: $isFetchingGroups, groups: $groups, activeGroups: $activeGroups, stocks: $stocks, activeGroupExtras: $activeGroupExtras, activeExtrasIndex: $activeExtrasIndex)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_EditFoodStocksState &&
            (identical(other.isLoading, isLoading) ||
                other.isLoading == isLoading) &&
            (identical(other.isSaving, isSaving) ||
                other.isSaving == isSaving) &&
            (identical(other.isFetchingGroups, isFetchingGroups) ||
                other.isFetchingGroups == isFetchingGroups) &&
            const DeepCollectionEquality().equals(other._groups, _groups) &&
            const DeepCollectionEquality()
                .equals(other._activeGroups, _activeGroups) &&
            const DeepCollectionEquality().equals(other._stocks, _stocks) &&
            const DeepCollectionEquality()
                .equals(other._activeGroupExtras, _activeGroupExtras) &&
            (identical(other.activeExtrasIndex, activeExtrasIndex) ||
                other.activeExtrasIndex == activeExtrasIndex));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      isLoading,
      isSaving,
      isFetchingGroups,
      const DeepCollectionEquality().hash(_groups),
      const DeepCollectionEquality().hash(_activeGroups),
      const DeepCollectionEquality().hash(_stocks),
      const DeepCollectionEquality().hash(_activeGroupExtras),
      activeExtrasIndex);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_EditFoodStocksStateCopyWith<_$_EditFoodStocksState> get copyWith =>
      __$$_EditFoodStocksStateCopyWithImpl<_$_EditFoodStocksState>(
          this, _$identity);
}

abstract class _EditFoodStocksState extends EditFoodStocksState {
  const factory _EditFoodStocksState(
      {final bool isLoading,
      final bool isSaving,
      final bool isFetchingGroups,
      final List<Group> groups,
      final List<Group> activeGroups,
      final List<Stock> stocks,
      final List<Extras> activeGroupExtras,
      final int activeExtrasIndex}) = _$_EditFoodStocksState;
  const _EditFoodStocksState._() : super._();

  @override
  bool get isLoading;
  @override
  bool get isSaving;
  @override
  bool get isFetchingGroups;
  @override
  List<Group> get groups;
  @override
  List<Group> get activeGroups;
  @override
  List<Stock> get stocks;
  @override
  List<Extras> get activeGroupExtras;
  @override
  int get activeExtrasIndex;
  @override
  @JsonKey(ignore: true)
  _$$_EditFoodStocksStateCopyWith<_$_EditFoodStocksState> get copyWith =>
      throw _privateConstructorUsedError;
}
