import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'edit_food_details_state.dart';
import '../../../../domain/interface/interfaces.dart';
import '../../../../infrastructure/models/models.dart';
import '../../../../infrastructure/services/services.dart';

class EditFoodDetailsNotifier extends StateNotifier<EditFoodDetailsState> {
  final ProductsRepository _productsRepository;
  final SettingsRepository _settingsRepository;
  String? _oldBarcode;

  EditFoodDetailsNotifier(this._productsRepository, this._settingsRepository)
      : super(const EditFoodDetailsState());

  void setTax(String value) {
    state = state.copyWith(tax: value.trim());
  }

  void setMaxQty(String value) {
    state = state.copyWith(maxQty: value.trim());
  }

  void setMinQty(String value) {
    state = state.copyWith(minQty: value.trim());
  }

  void setActive(bool? value) {
    final product =
        state.product?.copyWith(active: !(state.product?.active ?? false));
    state = state.copyWith(product: product);
  }

  Future<void> updateProduct(BuildContext context,{
    UnitData? unit,
    CategoryData? category,
    Function(ProductData?)? updated,
    VoidCallback? failed,
  }) async {
    state = state.copyWith(isLoading: true);
    String? imageUrl;
    if (state.imageFilePath != null) {
      final imageResponse = await _settingsRepository.uploadImage(
        state.imageFilePath!,
        UploadType.products,
      );
      imageResponse.when(
        success: (data) {
          imageUrl = data.imageData?.title;
        },
        failure: (fail,status) {
          debugPrint('===> product image upload fail $fail');
          AppHelpers.showCheckTopSnackBar(
              context,
              text: AppHelpers.trans(
                status.toString(),
              ),
              type: SnackBarType.error
          );
        },
      );
    }
    final response = await _productsRepository.updateProduct(
      title: state.title,
      description: state.description,
      tax: state.tax,
      maxQty: state.maxQty,
      minQty: state.minQty,
      qrcode: state.barcode == _oldBarcode ? null : state.barcode,
      active: state.active,
      categoryId: category?.id,
      unitId: unit?.id,
      image: imageUrl ?? state.product?.img,
      uuid: state.product?.uuid,
    );
    response.when(
      success: (data) {
        state = state.copyWith(isLoading: false);
        final updatedTranslation = state.product?.translation?.copyWith(
          title: state.title,
          description: state.description,
        );
        final updatedProduct = state.product?.copyWith(
          translation: updatedTranslation,
          tax: num.tryParse(state.tax),
          maxQty: int.tryParse(state.maxQty),
          minQty: int.tryParse(state.minQty),
          barCode: state.barcode,
          active: state.active,
          categoryId: category?.id,
          category: category,
          unit: unit,
          img: imageUrl,
        );
        _oldBarcode = state.barcode;
        updated?.call(updatedProduct);
      },
      failure: (fail,status) {
        AppHelpers.showCheckTopSnackBar(
            context,
            text: AppHelpers.trans(
              status.toString(),
            ),
            type: SnackBarType.error
        );
        state = state.copyWith(isLoading: false);
        debugPrint('===> product update fail $fail');
        failed?.call();
      },
    );
  }

  void setBarcode(String value) {
    state = state.copyWith(barcode: value.trim());
  }

  void setDescription(String value) {
    state = state.copyWith(description: value.trim());
  }

  void setTitle(String value) {
    state = state.copyWith(title: value.trim());
  }

  void setImageFile(String? filePath) {
    state = state.copyWith(imageFilePath: filePath);
  }

  void setFoodDetails(ProductData? product) {
    state = state.copyWith(
      product: product,
      imageFilePath: null,
      minQty: product?.minQty.toString() ?? '',
      maxQty: product?.maxQty.toString() ?? '',
      tax: product?.tax == null ? '' : (product?.tax.toString() ?? ''),
      title: product?.translation?.title ?? '',
      description: product?.translation?.description ?? '',
      barcode: product?.barCode ?? '',
      active: product?.active ?? false,
    );
    _oldBarcode = product?.barCode;
  }
}
