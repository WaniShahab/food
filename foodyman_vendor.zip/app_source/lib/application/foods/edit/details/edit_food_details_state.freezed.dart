// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'edit_food_details_state.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$EditFoodDetailsState {
  bool get isLoading => throw _privateConstructorUsedError;
  bool get active => throw _privateConstructorUsedError;
  String get title => throw _privateConstructorUsedError;
  String get description => throw _privateConstructorUsedError;
  String get minQty => throw _privateConstructorUsedError;
  String get maxQty => throw _privateConstructorUsedError;
  String get tax => throw _privateConstructorUsedError;
  String get barcode => throw _privateConstructorUsedError;
  ProductData? get product => throw _privateConstructorUsedError;
  String? get imageFilePath => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $EditFoodDetailsStateCopyWith<EditFoodDetailsState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $EditFoodDetailsStateCopyWith<$Res> {
  factory $EditFoodDetailsStateCopyWith(EditFoodDetailsState value,
          $Res Function(EditFoodDetailsState) then) =
      _$EditFoodDetailsStateCopyWithImpl<$Res, EditFoodDetailsState>;
  @useResult
  $Res call(
      {bool isLoading,
      bool active,
      String title,
      String description,
      String minQty,
      String maxQty,
      String tax,
      String barcode,
      ProductData? product,
      String? imageFilePath});
}

/// @nodoc
class _$EditFoodDetailsStateCopyWithImpl<$Res,
        $Val extends EditFoodDetailsState>
    implements $EditFoodDetailsStateCopyWith<$Res> {
  _$EditFoodDetailsStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isLoading = null,
    Object? active = null,
    Object? title = null,
    Object? description = null,
    Object? minQty = null,
    Object? maxQty = null,
    Object? tax = null,
    Object? barcode = null,
    Object? product = freezed,
    Object? imageFilePath = freezed,
  }) {
    return _then(_value.copyWith(
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      active: null == active
          ? _value.active
          : active // ignore: cast_nullable_to_non_nullable
              as bool,
      title: null == title
          ? _value.title
          : title // ignore: cast_nullable_to_non_nullable
              as String,
      description: null == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String,
      minQty: null == minQty
          ? _value.minQty
          : minQty // ignore: cast_nullable_to_non_nullable
              as String,
      maxQty: null == maxQty
          ? _value.maxQty
          : maxQty // ignore: cast_nullable_to_non_nullable
              as String,
      tax: null == tax
          ? _value.tax
          : tax // ignore: cast_nullable_to_non_nullable
              as String,
      barcode: null == barcode
          ? _value.barcode
          : barcode // ignore: cast_nullable_to_non_nullable
              as String,
      product: freezed == product
          ? _value.product
          : product // ignore: cast_nullable_to_non_nullable
              as ProductData?,
      imageFilePath: freezed == imageFilePath
          ? _value.imageFilePath
          : imageFilePath // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_EditFoodDetailsStateCopyWith<$Res>
    implements $EditFoodDetailsStateCopyWith<$Res> {
  factory _$$_EditFoodDetailsStateCopyWith(_$_EditFoodDetailsState value,
          $Res Function(_$_EditFoodDetailsState) then) =
      __$$_EditFoodDetailsStateCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {bool isLoading,
      bool active,
      String title,
      String description,
      String minQty,
      String maxQty,
      String tax,
      String barcode,
      ProductData? product,
      String? imageFilePath});
}

/// @nodoc
class __$$_EditFoodDetailsStateCopyWithImpl<$Res>
    extends _$EditFoodDetailsStateCopyWithImpl<$Res, _$_EditFoodDetailsState>
    implements _$$_EditFoodDetailsStateCopyWith<$Res> {
  __$$_EditFoodDetailsStateCopyWithImpl(_$_EditFoodDetailsState _value,
      $Res Function(_$_EditFoodDetailsState) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isLoading = null,
    Object? active = null,
    Object? title = null,
    Object? description = null,
    Object? minQty = null,
    Object? maxQty = null,
    Object? tax = null,
    Object? barcode = null,
    Object? product = freezed,
    Object? imageFilePath = freezed,
  }) {
    return _then(_$_EditFoodDetailsState(
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      active: null == active
          ? _value.active
          : active // ignore: cast_nullable_to_non_nullable
              as bool,
      title: null == title
          ? _value.title
          : title // ignore: cast_nullable_to_non_nullable
              as String,
      description: null == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String,
      minQty: null == minQty
          ? _value.minQty
          : minQty // ignore: cast_nullable_to_non_nullable
              as String,
      maxQty: null == maxQty
          ? _value.maxQty
          : maxQty // ignore: cast_nullable_to_non_nullable
              as String,
      tax: null == tax
          ? _value.tax
          : tax // ignore: cast_nullable_to_non_nullable
              as String,
      barcode: null == barcode
          ? _value.barcode
          : barcode // ignore: cast_nullable_to_non_nullable
              as String,
      product: freezed == product
          ? _value.product
          : product // ignore: cast_nullable_to_non_nullable
              as ProductData?,
      imageFilePath: freezed == imageFilePath
          ? _value.imageFilePath
          : imageFilePath // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc

class _$_EditFoodDetailsState extends _EditFoodDetailsState {
  const _$_EditFoodDetailsState(
      {this.isLoading = false,
      this.active = false,
      this.title = '',
      this.description = '',
      this.minQty = '',
      this.maxQty = '',
      this.tax = '',
      this.barcode = '',
      this.product,
      this.imageFilePath})
      : super._();

  @override
  @JsonKey()
  final bool isLoading;
  @override
  @JsonKey()
  final bool active;
  @override
  @JsonKey()
  final String title;
  @override
  @JsonKey()
  final String description;
  @override
  @JsonKey()
  final String minQty;
  @override
  @JsonKey()
  final String maxQty;
  @override
  @JsonKey()
  final String tax;
  @override
  @JsonKey()
  final String barcode;
  @override
  final ProductData? product;
  @override
  final String? imageFilePath;

  @override
  String toString() {
    return 'EditFoodDetailsState(isLoading: $isLoading, active: $active, title: $title, description: $description, minQty: $minQty, maxQty: $maxQty, tax: $tax, barcode: $barcode, product: $product, imageFilePath: $imageFilePath)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_EditFoodDetailsState &&
            (identical(other.isLoading, isLoading) ||
                other.isLoading == isLoading) &&
            (identical(other.active, active) || other.active == active) &&
            (identical(other.title, title) || other.title == title) &&
            (identical(other.description, description) ||
                other.description == description) &&
            (identical(other.minQty, minQty) || other.minQty == minQty) &&
            (identical(other.maxQty, maxQty) || other.maxQty == maxQty) &&
            (identical(other.tax, tax) || other.tax == tax) &&
            (identical(other.barcode, barcode) || other.barcode == barcode) &&
            (identical(other.product, product) || other.product == product) &&
            (identical(other.imageFilePath, imageFilePath) ||
                other.imageFilePath == imageFilePath));
  }

  @override
  int get hashCode => Object.hash(runtimeType, isLoading, active, title,
      description, minQty, maxQty, tax, barcode, product, imageFilePath);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_EditFoodDetailsStateCopyWith<_$_EditFoodDetailsState> get copyWith =>
      __$$_EditFoodDetailsStateCopyWithImpl<_$_EditFoodDetailsState>(
          this, _$identity);
}

abstract class _EditFoodDetailsState extends EditFoodDetailsState {
  const factory _EditFoodDetailsState(
      {final bool isLoading,
      final bool active,
      final String title,
      final String description,
      final String minQty,
      final String maxQty,
      final String tax,
      final String barcode,
      final ProductData? product,
      final String? imageFilePath}) = _$_EditFoodDetailsState;
  const _EditFoodDetailsState._() : super._();

  @override
  bool get isLoading;
  @override
  bool get active;
  @override
  String get title;
  @override
  String get description;
  @override
  String get minQty;
  @override
  String get maxQty;
  @override
  String get tax;
  @override
  String get barcode;
  @override
  ProductData? get product;
  @override
  String? get imageFilePath;
  @override
  @JsonKey(ignore: true)
  _$$_EditFoodDetailsStateCopyWith<_$_EditFoodDetailsState> get copyWith =>
      throw _privateConstructorUsedError;
}
