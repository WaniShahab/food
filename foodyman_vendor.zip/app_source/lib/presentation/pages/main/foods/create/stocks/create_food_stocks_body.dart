import 'package:flutter/material.dart';
import 'package:auto_route/auto_route.dart';
import 'package:flutter_remix/flutter_remix.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../../../styles/style.dart';
import 'create_food_addons_modal.dart';
import 'create_food_edit_extras_modal.dart';
import '../../../../../component/components.dart';
import '../../../../../../application/providers.dart';
import '../../../../../../infrastructure/services/services.dart';

class CreateFoodStocksBody extends ConsumerStatefulWidget {
  const CreateFoodStocksBody({Key? key}) : super(key: key);

  @override
  ConsumerState<CreateFoodStocksBody> createState() =>
      _CreateFoodStocksBodyState();
}

class _CreateFoodStocksBodyState extends ConsumerState<CreateFoodStocksBody> {
  final _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback(
      (_) => ref.read(createFoodStocksProvider.notifier).setInitialStocks(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return KeyboardDisable(
      child: Consumer(
        builder: (context, ref, child) {
          final state = ref.watch(createFoodStocksProvider);
          final event = ref.read(createFoodStocksProvider.notifier);
          final foodsEvent = ref.read(foodsProvider.notifier);
          final categoriesState = ref.watch(foodCategoriesProvider);
          final detailsState = ref.watch(createFoodDetailsProvider);
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              10.verticalSpace,
              SizedBox(
                height: 60.r,
                child: ListView.builder(
                  itemCount: state.groups.length,
                  scrollDirection: Axis.horizontal,
                  shrinkWrap: true,
                  padding: REdgeInsets.symmetric(horizontal: 16),
                  physics: const BouncingScrollPhysics(),
                  itemBuilder: (context, index) => ExtrasItem(
                    extras: state.groups[index],
                    onTap: () => event.toggleCheckedGroup(index),
                  ),
                ),
              ),
              Expanded(
                child: Form(
                  key: _formKey,
                  autovalidateMode: AutovalidateMode.onUserInteraction,
                  child: ListView.builder(
                    itemCount: state.stocks.length + 1,
                    shrinkWrap: true,
                    padding:
                        REdgeInsets.symmetric(vertical: 10, horizontal: 16),
                    physics: const BouncingScrollPhysics(),
                    itemBuilder: (context, index) {
                      return index == state.stocks.length
                          ? (state.activeGroups.isEmpty
                              ? const SizedBox.shrink()
                              : ButtonsBouncingEffect(
                                  child: GestureDetector(
                                    onTap: event.addEmptyStock,
                                    child: Container(
                                      height: 34.r,
                                      width: double.infinity,
                                      alignment: Alignment.center,
                                      decoration: BoxDecoration(
                                        borderRadius:
                                            BorderRadius.circular(8.r),
                                        color: Style.white,
                                      ),
                                      child: Icon(
                                        FlutterRemix.add_line,
                                        color: Style.blackColor,
                                        size: 22.r,
                                      ),
                                    ),
                                  ),
                                ))
                          : EditableFoodStockItem(
                              key: UniqueKey(),
                              isDeletable: index != 0,
                              stock: state.stocks[index],
                              onDeleteStock: () => event.deleteStock(index),
                              onPriceChange: (value) =>
                                  event.setPrice(value: value, index: index),
                              onQuantityChange: (value) =>
                                  event.setQuantity(value: value, index: index),
                              onEditExtrasGroupTap: (context, groupIndex) =>
                                  AppHelpers.showCustomModalBottomSheet(
                                paddingTop:
                                    MediaQuery.of(context).padding.top + 150,
                                context: context,
                                radius: 12,
                                modal: CreateFoodEditExtrasModal(
                                  groupIndex: groupIndex,
                                  stockIndex: index,
                                ),
                                isDarkMode: true,
                              ),
                              onAddonTap: (context) =>
                                  AppHelpers.showCustomModalBottomSheet(
                                    paddingTop:
                                    MediaQuery.of(context).padding.top + 150,
                                    context: context,
                                    radius: 12,
                                    modal: CreateFoodAddonsModal(
                                      stock: state.stocks[index],
                                      onSave: (addons) =>
                                          event.setStockAddons(addons, index),
                                    ),
                                    isDarkMode: true,
                                  ),
                            );
                    },
                  ),
                ),
              ),
              Padding(
                padding: REdgeInsets.symmetric(horizontal: 20),
                child: CustomButton(
                  title: AppHelpers.trans(TrKeys.save),
                  isLoading: state.isSaving,
                  onPressed: () {
                    if (_formKey.currentState?.validate() ?? false) {
                      event.updateStocks(
                        context,
                        uuid: detailsState.createdProduct?.uuid,
                        updated: () {
                          foodsEvent.fetchProducts(
                            isRefresh: true,
                            categoryId: categoriesState.activeIndex == 1
                                ? null
                                : categoriesState
                                    .categories[categoriesState.activeIndex - 2]
                                    .id,
                          );
                          AppHelpers.showCheckTopSnackBar(
                            context,
                            type: SnackBarType.success,
                            text: AppHelpers.trans(TrKeys.successfullyUpdated),
                          );
                          context.popRoute();
                        },
                        failed: () => AppHelpers.showCheckTopSnackBar(
                          context,
                          type: SnackBarType.error,
                          text: AppHelpers.trans(TrKeys.updateFailed),
                        ),
                      );
                    }
                  },
                ),
              ),
              20.verticalSpace,
            ],
          );
        },
      ),
    );
  }
}
